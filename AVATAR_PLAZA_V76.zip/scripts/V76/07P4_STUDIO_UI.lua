-- 07P4_STUDIO_UI | ModuleScript | ReplicatedStorage | V76 (SUBSTITUIR)
-- Barra lateral, avatar em cena e paineis contextuais sem rolagem.
local Rep=game:GetService("ReplicatedStorage")
local D=require(Rep:WaitForChild("07UI_DESIGN_SYSTEM"));local C=D.Colors
local Bounds=require(Rep:WaitForChild("07UI_SCREEN_BOUNDS"))
local M={Version='V76'};local navOrder={"Pose","Animations","Background","Environment","Camera","Video","Capture"}
function M.Build(pl)
 local pg=pl:WaitForChild("PlayerGui");local old=pg:FindFirstChild("ACP_PhotoMode");if old then old:Destroy()end
 local gui=D.New("ScreenGui",{Name="ACP_PhotoMode",ResetOnSpawn=false,IgnoreGuiInset=true,ScreenInsets=Enum.ScreenInsets.None,SafeAreaCompatibility=Enum.SafeAreaCompatibility.None,ClipToDeviceSafeArea=false,DisplayOrder=220,ZIndexBehavior=Enum.ZIndexBehavior.Sibling},pg)
 local U={Gui=gui,Buttons={},Axes={},Environment={},PoseMode=false,MenuOpen=true};local safe=Bounds.Bind(gui)
 U.Root=D.New("Frame",{Name="PhotoStudio",Size=UDim2.fromScale(1,1),BackgroundTransparency=1,Visible=false},gui)
 U.Title=D.Text(U.Root,"Estúdio de fotos",{Font=Enum.Font.GothamBold,TextSize=20,TextXAlignment=Enum.TextXAlignment.Left,BackgroundTransparency=1,ZIndex=10})
 U.Close=D.IconButton(U.Root,"ClosePhoto","close","Fechar Photo Mode",{Size=UDim2.fromOffset(48,48),ZIndex=40})
 U.Nav=D.Frame(U.Root,{Name="PhotoSidebar",BackgroundColor3=C.panel,BackgroundTransparency=.08,ZIndex=15})
 for i,p in ipairs({{"Pose","Pose","avatar"},{"Animations","Emotes","emote"},{"Background","Fundos","catalog"},{"Environment","Luz","settings"},{"Camera","Câmera","camera"},{"Video","Vídeo","camera"},{"Capture","Foto","save"}})do
  local b=D.Button(U.Nav,p[2],{Name="Photo"..p[1],TextSize=12,ZIndex=16});U.Buttons[p[1]]=b
  b.TextYAlignment=Enum.TextYAlignment.Bottom
  D.Icon(b,p[3],{AnchorPoint=Vector2.new(.5,0),Position=UDim2.new(.5,0,0,4),Size=UDim2.fromOffset(18,18),ZIndex=17})
 end
 U.Shutter=D.IconButton(U.Root,'TakePhoto','camera','Tirar foto sem interface',{Size=UDim2.fromOffset(48,48),BackgroundColor3=Color3.fromRGB(222,235,245),TextColor3=Color3.fromRGB(34,51,69),ZIndex=45})
 U.Buttons.Hide=D.Button(U.Root,"Sem interface",{TextSize=12,ZIndex=40})
 U.DragMode=D.Button(U.Root,"Girar avatar",{TextSize=12,ZIndex=40})
 U.ToolsToggle=D.IconButton(U.Root,"TogglePhotoTools","menu","Mostrar ou ocultar ferramentas",{ZIndex=40})
 U.Popup=D.Frame(U.Root,{Name="PhotoTools",BackgroundColor3=C.panel,BackgroundTransparency=.02,Visible=false,ZIndex=30})
 D.Stroke(U.Popup,C.orange,.48,1);D.New("UIGradient",{Color=ColorSequence.new(Color3.fromRGB(58,60,67),Color3.fromRGB(40,42,48)),Rotation=110},U.Popup)
 U.PopupTitle=D.Text(U.Popup,"",{Position=UDim2.fromOffset(12,4),Size=UDim2.new(1,-72,0,44),Font=Enum.Font.GothamBold,TextSize=18,TextXAlignment=Enum.TextXAlignment.Left,ZIndex=31})
 U.PopupClose=D.IconButton(U.Popup,"CloseTools","close","Fechar painel",{AnchorPoint=Vector2.new(1,0),Position=UDim2.new(1,-6,0,4),Size=UDim2.fromOffset(48,48),ZIndex=32})
 U.Content=D.Scroll(U.Popup,{Position=UDim2.fromOffset(8,56),Size=UDim2.new(1,-16,1,-64),BackgroundTransparency=1,ZIndex=31,ScrollBarThickness=2,AutomaticCanvasSize=Enum.AutomaticSize.None})
 U.ContentGrid=D.New("UIGridLayout",{CellPadding=UDim2.fromOffset(6,6),SortOrder=Enum.SortOrder.LayoutOrder},U.Content)
 U.PoseFooter=D.New("Frame",{AnchorPoint=Vector2.new(0,1),Position=UDim2.new(0,8,1,-8),Size=UDim2.new(1,-16,0,44),BackgroundTransparency=1,Visible=false,ZIndex=32},U.Popup)
 U.PoseReset=D.IconButton(U.PoseFooter,"ResetPose","reset","Restaurar pose",{Size=UDim2.fromOffset(44,44),ZIndex=33})
 U.PoseCancel=D.Button(U.PoseFooter,"Cancelar",{Size=UDim2.new(.5,-3,1,0),ZIndex=33})
 U.PoseConfirm=D.Button(U.PoseFooter,"Aplicar",{Position=UDim2.new(.5,3,0,0),Size=UDim2.new(.5,-3,1,0),BackgroundColor3=C.green,TextColor3=C.bg,ZIndex=33})
 U.Restore=D.Button(U.Root,"Mostrar UI",{Size=UDim2.fromOffset(118,44),Visible=false,BackgroundTransparency=.15,ZIndex=50})
 U.Status=D.Text(U.Root,"",{Name="PhotoNotice",TextSize=12,BackgroundTransparency=1,TextXAlignment=Enum.TextXAlignment.Left,Visible=false,ZIndex=12})
 local noticeId=0
 function U.Notify(text)
  noticeId=noticeId+1;local id=noticeId;U.Status.Text=tostring(text or"");U.Status.Visible=U.Status.Text~=""and not U.Restore.Visible
  task.delay(5,function()if noticeId==id then U.Status.Visible=false end end)
 end
 function U.Clear()
  if U.CameraChoices then U.CameraChoices.Hide()end
  if U.PoseEditor then U.PoseEditor.Destroy();U.PoseEditor=nil end
  U.PoseMode=false;U.CatalogMode=false;U.CatalogKind=nil;U.Content.Visible=true
  for _,o in ipairs(U.Content:GetChildren())do if o:IsA("GuiObject")then o:Destroy()end end
  U.Axes={};U.Environment={}
 end
 function U.Row(label,value,order)
  local row=D.Frame(U.Content,{BackgroundColor3=C.card,LayoutOrder=order or 0,ZIndex=32});row:SetAttribute("MinimumCellHeight",66)
  D.Text(row,label,{Position=UDim2.fromOffset(4,0),Size=UDim2.new(1,-8,0,20),TextSize=12,ZIndex=33})
  local minus=D.Button(row,"−",{Position=UDim2.new(0,2,0,21),Size=UDim2.new(0,44,1,-22),ZIndex=33})
  local box=D.Box(row,"",{Position=UDim2.new(0,46,0,21),Size=UDim2.new(1,-92,1,-22),Text=tostring(value),TextSize=12,ZIndex=33,TextXAlignment=Enum.TextXAlignment.Center})
  local plus=D.Button(row,"+",{Position=UDim2.new(1,-46,0,21),Size=UDim2.new(0,44,1,-22),ZIndex=33})
  local pad=box:FindFirstChildOfClass("UIPadding");if pad then pad.PaddingLeft=UDim.new(0,0);pad.PaddingRight=UDim.new(0,0)end
  return{Minus=minus,Value=box,Plus=plus,Root=row}
 end
 function U.Option(label,order,color)
  return D.Button(U.Content,label,{Size=UDim2.new(1,-4,0,44),LayoutOrder=order or 0,BackgroundColor3=color or C.card,ZIndex=32,TextSize=13})
 end
 function U.Pair(left,right,order)
  local row=D.New("Frame",{BackgroundTransparency=1,LayoutOrder=order or 0,ZIndex=32},U.Content)
  local a=D.Button(row,left,{Size=UDim2.new(.5,-3,1,0),ZIndex=33,TextSize=11})
  local b=D.Button(row,right,{Position=UDim2.new(.5,3,0,0),Size=UDim2.new(.5,-3,1,0),ZIndex=33,TextSize=11})
  return a,b
 end
 function U.TextLine(label,order)
  return D.Text(U.Content,label,{Size=UDim2.new(1,-4,0,44),TextSize=13,TextColor3=C.muted,TextXAlignment=Enum.TextXAlignment.Left,LayoutOrder=order or 0,ZIndex=32})
 end
 function U.Select(key)
  for name,b in pairs(U.Buttons)do if name~="Hide"then b.BackgroundColor3=name==key and Color3.fromRGB(247,228,209)or C.card end end
 end
 function U.SetClean(on)
  U.Shutter.Visible=not on;U.Title.Visible=not on;U.Close.Visible=not on;U.Nav.Visible=not on;U.Status.Visible=false;U.Buttons.Hide.Visible=not on;U.DragMode.Visible=not on
  U.Popup.Visible=false;U.Restore.Visible=on;U.ToolsToggle.Visible=not on;U.Layout()
 end
 function U.Layout()
  local il,it,ir,ib,w,h=safe.Read();if w<1 or h<1 then return end
  local aw=w-il-ir;local ah=h-it-ib;local landscape=aw>=480 and w>h;local clean=U.Restore.Visible
  local narrow=aw<420;local nw=narrow and 60 or 78;local packed=ah<410
  if packed then nw=108 end
  U.Nav.Visible=not clean and U.MenuOpen and not U.PoseMode and(landscape or not U.Popup.Visible)
  local navH=packed and 204 or 348;Bounds.Rect(U.Nav,w-ir-nw-6,it+54,nw,math.min(navH,ah-60))
  for i,key in ipairs(navOrder)do local b=U.Buttons[key];local x=packed and(i-1)%2*50+4 or 4;local y=packed and math.floor((i-1)/2)*50+4 or(i-1)*49+4
   Bounds.Rect(b,x,y,packed and 46 or nw-8,44);b.TextSize=packed and 9 or narrow and 10 or 12
   local pad=b:FindFirstChildOfClass("UIPadding");if pad then pad.PaddingLeft=UDim.new(0,1);pad.PaddingRight=UDim.new(0,1);pad.PaddingBottom=UDim.new(0,1)end
  end
  local left=8;local right=U.Nav.Visible and nw+18 or 8
  Bounds.Rect(U.Title,il+54,it+4,math.max(50,aw-344),44);Bounds.Rect(U.ToolsToggle,il+6,it+4,44,44);Bounds.Rect(U.Close,w-ir-56,it+4,48,48)
  Bounds.Rect(U.Buttons.Hide,w-ir-150,it+6,88,44);Bounds.Rect(U.Restore,w-ir-126,it+6,118,44)
  Bounds.Rect(U.Shutter,il+(aw-48)/2,h-ib-56,48,48);U.Shutter.Visible=not clean
  Bounds.Rect(U.DragMode,w-ir-282,it+6,126,44);U.DragMode.Visible=not clean and not U.PoseMode and not U.Popup.Visible
  if not landscape then Bounds.Rect(U.DragMode,il+left,it+52,126,44);Bounds.Rect(U.Title,il+60,it+4,math.max(50,aw-216),44)end
  local pw=landscape and math.min(400,math.max(260,aw*.40))or aw-12
  local ph=landscape and ah-12 or math.min(340,math.max(240,ah*.44));local px=landscape and w-ir-right-pw-6 or il+6;local py=landscape and it+6 or h-ib-ph-6
  if U.CatalogMode then
   pw=landscape and math.max(260,math.min(360,aw*.38))or math.min(360,aw-12)
   ph=math.min(ah-(landscape and aw>=640 and 12 or 72),U.CatalogKind=='Background'and 320 or 404);px=w-ir-pw-6;py=landscape and it+6 or h-ib-ph-64
   U.Nav.Visible=false;right=8
  end
  if U.PoseMode and landscape then pw=math.min(370,aw*.40);px=w-ir-right-pw-6 end
  Bounds.Rect(U.Popup,px,py,pw,ph);U.Content.Visible=not U.PoseMode
  if U.Popup.Visible and landscape then
   Bounds.Rect(U.Title,il+60,it+4,math.max(50,aw-pw-78),44)
   Bounds.Rect(U.Close,il+left,it+52,48,48);Bounds.Rect(U.Buttons.Hide,il+left+54,it+54,88,44)
   Bounds.Rect(U.DragMode,il+left+148,it+54,126,44)
  end
  local count=0;local minimum=44;for _,o in ipairs(U.Content:GetChildren())do if o:IsA("GuiObject")then count=count+1;minimum=math.max(minimum,tonumber(o:GetAttribute("MinimumCellHeight"))or 44)end end
  local cols=count<=4 and 2 or pw>=320 and 3 or 2;local rows=math.max(1,math.ceil(count/cols))
  if(ph-64-(rows-1)*6)/rows<44 and pw>=284 then cols=3;rows=math.max(1,math.ceil(count/cols))end
  if(ph-64-(rows-1)*6)/rows<44 and pw>=284 then cols=4;rows=math.max(1,math.ceil(count/cols))end
  local cw=(pw-16-(cols-1)*6)/cols
  if U.CatalogMode then cols=1;rows=1;cw=pw-16 end
  local cellH=U.CatalogMode and ph-64 or math.max(minimum,(ph-64-(rows-1)*6)/rows);U.ContentGrid.FillDirectionMaxCells=cols;U.ContentGrid.CellSize=UDim2.fromOffset(cw,cellH);U.Content.CanvasSize=UDim2.fromOffset(0,rows*(cellH+6)-6);U.Content.ScrollingEnabled=not U.CatalogMode and rows*(cellH+6)-6>ph-64
  U.PoseCancel.Position=UDim2.fromOffset(46,0);U.PoseCancel.Size=UDim2.new(.5,-26,1,0);U.PoseConfirm.Position=UDim2.new(.5,24,0,0);U.PoseConfirm.Size=UDim2.new(.5,-24,1,0)
  U.PoseCancel.TextSize=pw<230 and 11 or 13;U.PoseConfirm.TextSize=pw<230 and 12 or 14
  local statusW=math.max(70,math.min(340,aw*.5-42))
  Bounds.Rect(U.Status,il+left,h-ib-40,math.max(60,statusW),32)
  U.SceneMargins={0,0,0,0}
  if U.OnLayout then U.OnLayout(il,it,ir,ib,w,h,landscape,it+54)end
 end
 U.ToolsToggle.Activated:Connect(function()U.MenuOpen=not U.MenuOpen;U.Layout()end)
 safe.Watch(U.Layout);U.Popup:GetPropertyChangedSignal("Visible"):Connect(U.Layout);U.PoseFooter:GetPropertyChangedSignal("Visible"):Connect(U.Layout)
 return U
end
return M
